<div class="container">
    <div class="navbars__brand">
        <div class="navbars__brand--title">THỐNG KÊ DOANH THU</div>

    </div>

<p>Thống kê đơn hàng: <span id="text-date"></span></p>
<p>
    <select class="select-date" name="" id="">
        <option value="7ngay">7 ngày qua</option>
        <option value="14ngay">14 ngày qua</option>
        <option value="21ngay">21 ngày qua</option>
        <option value="30ngay">60 ngày qua</option>
    </select>
</p>
<div id="chart" style="height: 250px;"></div>

</div>
<script>
    
</script>