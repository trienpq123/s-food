<div class="col-lg-3">
            <div class="navbars--clone">
                <div class="navbars">
                    <div class="navbars__brand">
                        <div class="navbars__brand--title">S-FOOD</div>
                        <div class="navbars__brand--iconl"><i class="fas fa-bars"></i></div>
                    </div>
             
                    <ul class="navbars_sidebars">
                        <li>
                            <a href="?quanly=category" class="active">Quản lý danh mục<i class="fas fa-chevron-down"></i></a>
                            <div class="navbars__submenu">
                                <ul>
                                    <li><a href="?quanly=category">Bảng danh mục</a></li>
                                    <li><a href="?quanly=categoryAdd">Thêm danh mục</a></li>
                                </ul>
                            </div>
                          
                        </li>
    
                        <li>
                            <a href="?quanly=productList">Quản lý món ăn <i class="fas fa-chevron-down"></i></a>
                            <div class="navbars__submenu">
                                <ul>
                                    <li><a href="?quanly=product_add">Thêm món ăn</a></li>
                                    <li><a href="?quanly=product_listReduce">Bảng giảm giá</a></li>
                                    <li><a href="?quanly=product_sale">Giảm giá</a></li>
                                    <li><a href="?quanly=product_addCode">Thêm mã khuyến mãi</a></li>
                                    <li><a href="?quanly=product_listCode">Chương trình khuyến mãi</a></li>
                                </ul>
                            </div>
                        </li>
    
                        <li>
                            <a href="?quanly=customer">Quản lý khách hàng</a>
                            
                        </li>
    
                        <li>
                            <a href="?quanly=order">Quản lý đơn hàng </a>
                        </li>
    
                        <li><a href="?quanly=comment">Quản lý bình luận</a></li>
                        <li><a href="?quanly=thongke">Thống kê sản phẩm</a></li>
    
                    <ul>
                   
                </div>
            </div>
        </div>